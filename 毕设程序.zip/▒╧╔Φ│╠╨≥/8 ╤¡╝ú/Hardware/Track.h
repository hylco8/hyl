#ifndef __TRACK_H
#define __TRACK_H

void Track_Init(void);
uint8_t L2 (void);
uint8_t L1 (void);
uint8_t M0 (void);
uint8_t R1 (void);
uint8_t R2 (void);
uint8_t Infrared (void); //����
void Patrol_Control(void);



#endif
