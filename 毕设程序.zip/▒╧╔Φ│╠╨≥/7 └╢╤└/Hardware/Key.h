#ifndef __KEY_
#define __KEY_

void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
