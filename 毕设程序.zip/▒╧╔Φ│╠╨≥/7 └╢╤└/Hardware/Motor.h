#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Init(void);

void Turnfront(void);
void Turnback(void);
void Turnleft(void);
void Turnright(void);
void Stop(void);

#endif
